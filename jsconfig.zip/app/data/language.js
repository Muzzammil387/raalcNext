export const language={
    "BOOK A CONSULTATION": "BOOK A CONSULTATION",
}