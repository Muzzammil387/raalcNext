import { createContext } from 'react';
export const MyHome = createContext("");