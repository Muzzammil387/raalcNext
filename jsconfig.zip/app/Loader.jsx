import React from 'react'

const Loader = () => {
  return (
    <div>
      
    </div>
  )
}

export default Loader
